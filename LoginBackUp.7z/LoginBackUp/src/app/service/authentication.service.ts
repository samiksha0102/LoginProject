import { Injectable } from '@angular/core';
import { User } from '@/bean/User';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  http: HttpClient;
  router:Router;
  user: User;
  constructor() { }

  fetchUser(userId:any) {

    this.http.put('http://localhost:6798/GetAccountDetails/'
    +userId,null).subscribe((data)=>
    {
      this.convertUser(data);
    },(errorC)=>
    { 
      console.log(errorC.error)
      alert(errorC.error.message)

    })
  }

  convertUser(data:any){
      this.user = new User(data.userId, data.userName, data.userPassword);
  }

  authenticate(userId, userPass) {
    this.fetchUser(userId);
    if (userId === this.user.userId && userPass === this.user.userPassword) {
      sessionStorage.setItem('userId', userId)
      return true;
    } else {
      return false;
    }
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('userId')
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('userId')
  }
}