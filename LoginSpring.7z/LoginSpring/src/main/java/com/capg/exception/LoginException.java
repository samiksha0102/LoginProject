package com.capg.exception;

public class LoginException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public LoginException()
	{
		super();
	}
	// Parameterized Constructor
	public LoginException(String msg)
	{
		super(msg);
	}
	
}
