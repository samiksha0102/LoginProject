package com.capg.service;

import com.capg.bean.LoginBean;


public interface LoginService {

	LoginBean findByUserId(int userId);
	
}
