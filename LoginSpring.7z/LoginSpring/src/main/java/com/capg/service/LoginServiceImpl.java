package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.capg.bean.LoginBean;
import com.capg.dao.LoginDao;
import com.capg.exception.LoginException;

public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginDao loginDao;

	@Override
	public LoginBean findByUserId(int userId) {
		LoginBean bean = loginDao.findByUserId(userId);
		return bean;
	}
}




